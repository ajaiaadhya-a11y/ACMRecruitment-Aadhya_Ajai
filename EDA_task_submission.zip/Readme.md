# Student Performance EDA Task

## What I Did:
1. Loaded the dataset and cleaned up duplicates.
2. Created 5 charts (Histogram, Bar Chart, Box Plot, Scatter Plot, Heatmap).
3. Wrote 5 key discoveries about how students perform in school.